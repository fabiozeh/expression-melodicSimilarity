Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - ldk1609 ( https://freesound.org/people/ldk1609/ )

You can find this pack online at: https://freesound.org/people/ldk1609/packs/3559/

License details
---------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 55913__ldk1609__violin_arco_non_vib_G5.aiff
    * url: https://freesound.org/s/55913/
    * license: Creative Commons 0
  * 55912__ldk1609__violin_arco_non_vib_G4.aiff
    * url: https://freesound.org/s/55912/
    * license: Creative Commons 0
  * 55911__ldk1609__violin_arco_non_vib_G3.aiff
    * url: https://freesound.org/s/55911/
    * license: Creative Commons 0
  * 55910__ldk1609__violin_arco_non_vib_G2.aiff
    * url: https://freesound.org/s/55910/
    * license: Creative Commons 0
  * 55909__ldk1609__violin_arco_non_vib_G_5.aiff
    * url: https://freesound.org/s/55909/
    * license: Creative Commons 0
  * 55908__ldk1609__violin_arco_non_vib_G_4.aiff
    * url: https://freesound.org/s/55908/
    * license: Creative Commons 0
  * 55907__ldk1609__violin_arco_non_vib_G_3.aiff
    * url: https://freesound.org/s/55907/
    * license: Creative Commons 0
  * 55906__ldk1609__violin_arco_non_vib_G_2.aiff
    * url: https://freesound.org/s/55906/
    * license: Creative Commons 0
  * 55905__ldk1609__violin_arco_non_vib_F5.aiff
    * url: https://freesound.org/s/55905/
    * license: Creative Commons 0
  * 55904__ldk1609__violin_arco_non_vib_F4.aiff
    * url: https://freesound.org/s/55904/
    * license: Creative Commons 0
  * 55903__ldk1609__violin_arco_non_vib_F3.aiff
    * url: https://freesound.org/s/55903/
    * license: Creative Commons 0
  * 55902__ldk1609__violin_arco_non_vib_F_5.aiff
    * url: https://freesound.org/s/55902/
    * license: Creative Commons 0
  * 55901__ldk1609__violin_arco_non_vib_F_4.aiff
    * url: https://freesound.org/s/55901/
    * license: Creative Commons 0
  * 55900__ldk1609__violin_arco_non_vib_F_3.aiff
    * url: https://freesound.org/s/55900/
    * license: Creative Commons 0
  * 55899__ldk1609__violin_arco_non_vib_E5.aiff
    * url: https://freesound.org/s/55899/
    * license: Creative Commons 0
  * 55898__ldk1609__violin_arco_non_vib_E4.aiff
    * url: https://freesound.org/s/55898/
    * license: Creative Commons 0
  * 55897__ldk1609__violin_arco_non_vib_E3.aiff
    * url: https://freesound.org/s/55897/
    * license: Creative Commons 0
  * 55896__ldk1609__violin_arco_non_vib_D5.aiff
    * url: https://freesound.org/s/55896/
    * license: Creative Commons 0
  * 55895__ldk1609__violin_arco_non_vib_D4.aiff
    * url: https://freesound.org/s/55895/
    * license: Creative Commons 0
  * 55894__ldk1609__violin_arco_non_vib_D3.aiff
    * url: https://freesound.org/s/55894/
    * license: Creative Commons 0
  * 55893__ldk1609__violin_arco_non_vib_D_5.aiff
    * url: https://freesound.org/s/55893/
    * license: Creative Commons 0
  * 55892__ldk1609__violin_arco_non_vib_D_4.aiff
    * url: https://freesound.org/s/55892/
    * license: Creative Commons 0
  * 55891__ldk1609__violin_arco_non_vib_D_3.aiff
    * url: https://freesound.org/s/55891/
    * license: Creative Commons 0
  * 55890__ldk1609__violin_arco_non_vib_C5.aiff
    * url: https://freesound.org/s/55890/
    * license: Creative Commons 0
  * 55889__ldk1609__violin_arco_non_vib_C4.aiff
    * url: https://freesound.org/s/55889/
    * license: Creative Commons 0
  * 55888__ldk1609__violin_arco_non_vib_C3.aiff
    * url: https://freesound.org/s/55888/
    * license: Creative Commons 0
  * 55887__ldk1609__violin_arco_non_vib_C_5.aiff
    * url: https://freesound.org/s/55887/
    * license: Creative Commons 0
  * 55886__ldk1609__violin_arco_non_vib_C_4.aiff
    * url: https://freesound.org/s/55886/
    * license: Creative Commons 0
  * 55885__ldk1609__violin_arco_non_vib_C_3.aiff
    * url: https://freesound.org/s/55885/
    * license: Creative Commons 0
  * 55884__ldk1609__violin_arco_non_vib_B5.aiff
    * url: https://freesound.org/s/55884/
    * license: Creative Commons 0
  * 55883__ldk1609__violin_arco_non_vib_B4.aiff
    * url: https://freesound.org/s/55883/
    * license: Creative Commons 0
  * 55882__ldk1609__violin_arco_non_vib_B3.aiff
    * url: https://freesound.org/s/55882/
    * license: Creative Commons 0
  * 55881__ldk1609__violin_arco_non_vib_B2.aiff
    * url: https://freesound.org/s/55881/
    * license: Creative Commons 0
  * 55880__ldk1609__violin_arco_non_vib_A5.aiff
    * url: https://freesound.org/s/55880/
    * license: Creative Commons 0
  * 55879__ldk1609__violin_arco_non_vib_A4.aiff
    * url: https://freesound.org/s/55879/
    * license: Creative Commons 0
  * 55878__ldk1609__violin_arco_non_vib_A3.aiff
    * url: https://freesound.org/s/55878/
    * license: Creative Commons 0
  * 55877__ldk1609__violin_arco_non_vib_A2.aiff
    * url: https://freesound.org/s/55877/
    * license: Creative Commons 0
  * 55876__ldk1609__violin_arco_non_vib_A_5.aiff
    * url: https://freesound.org/s/55876/
    * license: Creative Commons 0
  * 55875__ldk1609__violin_arco_non_vib_A_4.aiff
    * url: https://freesound.org/s/55875/
    * license: Creative Commons 0
  * 55874__ldk1609__violin_arco_non_vib_A_3.aiff
    * url: https://freesound.org/s/55874/
    * license: Creative Commons 0
  * 55873__ldk1609__violin_arco_non_vib_A_2.aiff
    * url: https://freesound.org/s/55873/
    * license: Creative Commons 0


