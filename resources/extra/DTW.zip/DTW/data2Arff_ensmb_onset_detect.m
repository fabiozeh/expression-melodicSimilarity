function data2Arff_ensmb_onset_detect
addpath('/Users/chechojazz/Dropbox/PHD/Libraries/SIGGuitarModelling');

data = csvread([pwd,'/FramesBinary.csv']);

data = nom2bin(data);

dataStruct.tony = data(:,1);
dataStruct.BGR = data(:,2);
dataStruct.Mcnab = data(:,3);
dataStruct.transition = data(:,4);

attrib = attributes(dataStruct,dataStruct);
arff_write([pwd,'/arffs/window0.arff'],dataStruct,'train',attrib,'window0');

for window = 4:4:40
   newData = createNewData(data,window);
   attrib = attributes(newData,newData);
   arff_write([pwd,'/arffs/window',num2str(window/4),'.arff'],newData,'train',attrib,['window',num2str(window/4)]);    
end
end
function newDataStruct = createNewData(data,window)
    
    midData = data(1+window:end-window,1:4);
    idx = [1+window:(2*window)+1:length(midData)];
    
    for i=window:-1:1
        prevData = data(1+window-i:end-window-i,:);
        newDataStruct.(['Prev',num2str(i),'_tony'])= prevData(idx,1);
        newDataStruct.(['Prev',num2str(i),'_BGR']) = prevData(idx,2);
        newDataStruct.(['Prev',num2str(i),'_Mcnab']) = prevData(idx,3);        
    end
    newDataStruct.tony = midData(idx,1);
    newDataStruct.BGR = midData(idx,2);
    newDataStruct.Mcnab = midData(idx,3);
    for i=1:1:window
        nextData = data(1+window+i:end-window+i,:);
        newDataStruct.(['Next',num2str(i),'_tony'])= nextData(idx,1);
        newDataStruct.(['Next',num2str(i),'_BGR']) = nextData(idx,2);
        newDataStruct.(['Next',num2str(i),'_Mcnab']) = nextData(idx,3);                
%        data2 = [prevData,midData,nextData];%needed...?
    end
    
   transition = midData(:,4);
   newDataStruct.transition = midData(idx,4);%to inizialize
   
    %downsample
    wSize = (2 * window) + 1;
    flag1 = 0;
    flag2 = mod (i,wSize);
    k = 1;
    for i=1:length(transition)   
       flag2=mod (i,wSize);
       if strcmp(transition(i),'y')
           flag1 = 1;
       end
       if  flag2 == 0
           if flag1 == 1
                newDataStruct.transition {k} = 'y';
                flag1 = 0;
           else
                newDataStruct.transition {k} = 'n';
           end
           k = k + 1;
       end
    end
        
end

function dataBin = nom2bin(data)

dataBin = [];
for i= 1:size(data,1)
    for j=1:size(data,2)
        switch data(i,j)
            case 1
                dataBin{i,j} = 'y';
            case 0
                dataBin{i,j} = 'n';
        end
    end
end

end

