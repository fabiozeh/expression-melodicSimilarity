%% parameters to optimize: Wp    , Wd  , Wo   ,Wilo      ,Wllo
x=[1,1,1,1,1];
lowbound=[0,0,0,0,0];
highbound=[1,1,1,1,1];
[X,FVAL,EXITFLAG,OUTPUT,POPULATION,SCORES] =ga(@DTW_eval_cost,6,[],[],[],[],lowbound,highbound,[]);
%get current folder

currentFolder=pwd;
save([currentFolder,'\output.mat']);